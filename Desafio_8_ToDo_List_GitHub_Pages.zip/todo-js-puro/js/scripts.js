const taskForm = document.querySelector("#task-form");
const taskInput = document.querySelector("#task-input");
const taskList = document.querySelector("#task-list");
const taskCount = document.querySelector("#task-count");
const emptyState = document.querySelector("#empty-state");
const searchInput = document.querySelector("#search-input");
const filterSelect = document.querySelector("#filter-select");
const clearDoneButton = document.querySelector("#clear-done");

let tasks = loadTasks();

function loadTasks() {
  try {
    const savedTasks = JSON.parse(localStorage.getItem("todo-tasks"));
    return Array.isArray(savedTasks) ? savedTasks : [];
  } catch {
    return [];
  }
}

function saveTasks() {
  localStorage.setItem("todo-tasks", JSON.stringify(tasks));
}

function renderTasks() {
  const searchTerm = searchInput.value.trim().toLocaleLowerCase("pt-BR");
  const filter = filterSelect.value;

  const visibleTasks = tasks.filter(task => {
    const matchesSearch = task.text.toLocaleLowerCase("pt-BR").includes(searchTerm);
    const matchesFilter =
      filter === "all" ||
      (filter === "done" && task.done) ||
      (filter === "todo" && !task.done);
    return matchesSearch && matchesFilter;
  });

  taskList.innerHTML = "";

  visibleTasks.forEach(task => {
    const item = document.createElement("li");
    item.className = `task-item${task.done ? " completed" : ""}`;

    const checkButton = document.createElement("button");
    checkButton.className = "check-button";
    checkButton.type = "button";
    checkButton.setAttribute("aria-label", task.done ? "Marcar como não feita" : "Marcar como feita");
    checkButton.innerHTML = '<i class="fa-solid fa-check"></i>';
    checkButton.addEventListener("click", () => toggleTask(task.id));

    const text = document.createElement("span");
    text.className = "task-text";
    text.textContent = task.text;

    const deleteButton = document.createElement("button");
    deleteButton.className = "delete-button";
    deleteButton.type = "button";
    deleteButton.setAttribute("aria-label", "Excluir tarefa");
    deleteButton.innerHTML = '<i class="fa-solid fa-trash"></i>';
    deleteButton.addEventListener("click", () => deleteTask(task.id));

    item.append(checkButton, text, deleteButton);
    taskList.appendChild(item);
  });

  const pending = tasks.filter(task => !task.done).length;
  taskCount.textContent = `${pending} pendente${pending === 1 ? "" : "s"}`;
  emptyState.hidden = visibleTasks.length > 0;
  if (tasks.length > 0 && visibleTasks.length === 0) {
    emptyState.textContent = "Nenhuma tarefa encontrada com esse filtro.";
  } else if (tasks.length === 0) {
    emptyState.innerHTML = '<i class="fa-regular fa-clipboard"></i><br>Você ainda não tem tarefas.<br>Adicione uma tarefa para começar!';
  }
}

function addTask(text) {
  tasks.unshift({ id: Date.now() + Math.random(), text, done: false });
  saveTasks();
  renderTasks();
}

function toggleTask(id) {
  tasks = tasks.map(task => task.id === id ? { ...task, done: !task.done } : task);
  saveTasks();
  renderTasks();
}

function deleteTask(id) {
  tasks = tasks.filter(task => task.id !== id);
  saveTasks();
  renderTasks();
}

taskForm.addEventListener("submit", event => {
  event.preventDefault();
  const text = taskInput.value.trim();
  if (!text) {
    taskInput.focus();
    return;
  }
  addTask(text);
  taskInput.value = "";
  taskInput.focus();
});

searchInput.addEventListener("keyup", renderTasks);
filterSelect.addEventListener("change", renderTasks);

clearDoneButton.addEventListener("click", () => {
  tasks = tasks.filter(task => !task.done);
  saveTasks();
  renderTasks();
});

renderTasks();

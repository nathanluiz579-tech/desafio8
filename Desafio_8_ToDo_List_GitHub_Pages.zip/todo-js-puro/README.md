# Minha Lista de Tarefas — Desafio 8

Projeto desenvolvido com HTML, CSS e JavaScript puro (vanilla).

## Como executar
1. Abra a pasta `todo-js-puro` no VS Code.
2. Instale a extensão Live Server, caso ainda não tenha.
3. Clique com o botão direito em `index.html` e escolha **Open with Live Server**.

## Funcionalidades
- Adicionar tarefas.
- Marcar tarefas como feitas ou pendentes.
- Excluir tarefas.
- Buscar tarefas enquanto digita.
- Filtrar: Todas, A fazer e Feitas.
- Salvar automaticamente no `localStorage`, mantendo os dados ao reabrir o navegador.
- Limpar todas as tarefas concluídas.

## Publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Abra o terminal nesta pasta e execute, substituindo os dados do repositório:

```bash
git init
git add .
git commit -m "Primeiro commit: lista de tarefas"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git push -u origin main
```

3. No GitHub, abra **Settings > Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação. O endereço será `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

Para atualizar o site depois, use:

```bash
git add .
git commit -m "Atualização do site"
git push
```

A imagem `img/bg.jpg` é opcional e não é necessária para o funcionamento do projeto.
